const PHOTO_EXAMPLES = {
  overall_front: {
    title: "Overall Front — Good Example",
    tips: [
      "Entire piece visible from top to bottom",
      "Camera held level, not angled up or down",
      "Legs and top both fully in frame",
      "Neutral, straight-on angle — no perspective distortion",
      "Even lighting — avoid harsh shadows across the face",
    ],
    // SVG: a simple cabinet schematic showing correct framing
    svg: `<svg viewBox="0 0 200 220" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%">
      <rect width="200" height="220" fill="#f5efe4"/>
      <!-- frame guide dashes -->
      <rect x="8" y="8" width="184" height="204" rx="2" fill="none" stroke="#d4c9b4" stroke-width="1" stroke-dasharray="4 3"/>
      <!-- piece body -->
      <rect x="38" y="30" width="124" height="150" rx="2" fill="#e8dcc8" stroke="#8b6914" stroke-width="1.5"/>
      <!-- top rail -->
      <rect x="38" y="30" width="124" height="14" rx="2" fill="#d4c4a0" stroke="#8b6914" stroke-width="1"/>
      <!-- two drawer faces -->
      <rect x="46" y="52" width="108" height="36" rx="1" fill="#ddd0b0" stroke="#8b6914" stroke-width="1"/>
      <circle cx="100" cy="70" r="4" fill="#8b6914"/>
      <rect x="46" y="96" width="108" height="36" rx="1" fill="#ddd0b0" stroke="#8b6914" stroke-width="1"/>
      <circle cx="100" cy="114" r="4" fill="#8b6914"/>
      <!-- door panel below drawers -->
      <rect x="46" y="140" width="50" height="34" rx="1" fill="#ddd0b0" stroke="#8b6914" stroke-width="1"/>
      <rect x="102" y="140" width="50" height="34" rx="1" fill="#ddd0b0" stroke="#8b6914" stroke-width="1"/>
      <!-- legs -->
      <rect x="42" y="180" width="10" height="28" rx="1" fill="#c8b888" stroke="#8b6914" stroke-width="1"/>
      <rect x="148" y="180" width="10" height="28" rx="1" fill="#c8b888" stroke="#8b6914" stroke-width="1"/>
      <!-- camera level indicator -->
      <line x1="8" y1="100" x2="28" y2="100" stroke="#5a6b52" stroke-width="1.5" stroke-dasharray="3 2"/>
      <line x1="172" y1="100" x2="192" y2="100" stroke="#5a6b52" stroke-width="1.5" stroke-dasharray="3 2"/>
      <!-- check mark -->
      <circle cx="170" cy="40" r="12" fill="#5a6b52"/>
      <path d="M164 40 l4 4 l8-8" stroke="white" stroke-width="2" fill="none" stroke-linecap="round"/>
    </svg>`,
  },
  overall_side: {
    title: "Overall Side / Profile — Good Example",
    tips: [
      "Full profile visible — top to floor",
      "Depth of the piece clearly shown",
      "Leg structure and taper visible",
      "Doors or leaves closed for a clean read",
      "Stand at the same height as the piece mid-point",
    ],
    svg: `<svg viewBox="0 0 200 220" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%">
      <rect width="200" height="220" fill="#f5efe4"/>
      <rect x="8" y="8" width="184" height="204" rx="2" fill="none" stroke="#d4c9b4" stroke-width="1" stroke-dasharray="4 3"/>
      <!-- side view of case — narrow profile -->
      <rect x="70" y="30" width="60" height="150" rx="2" fill="#e8dcc8" stroke="#8b6914" stroke-width="1.5"/>
      <!-- top -->
      <rect x="65" y="25" width="70" height="10" rx="1" fill="#d4c4a0" stroke="#8b6914" stroke-width="1"/>
      <!-- back edge line -->
      <line x1="130" y1="30" x2="130" y2="180" stroke="#8b6914" stroke-width="1" stroke-dasharray="3 2"/>
      <!-- depth arrow -->
      <line x1="70" y1="200" x2="130" y2="200" stroke="#5a6b52" stroke-width="1.5" marker-end="url(#arr)"/>
      <text x="92" y="215" font-size="9" fill="#5a6b52" font-family="sans-serif">depth</text>
      <!-- legs -->
      <rect x="74" y="180" width="8" height="26" rx="1" fill="#c8b888" stroke="#8b6914" stroke-width="1"/>
      <rect x="118" y="180" width="8" height="26" rx="1" fill="#c8b888" stroke="#8b6914" stroke-width="1"/>
      <!-- level line -->
      <line x1="8" y1="100" x2="60" y2="100" stroke="#5a6b52" stroke-width="1.5" stroke-dasharray="3 2"/>
      <line x1="140" y1="100" x2="192" y2="100" stroke="#5a6b52" stroke-width="1.5" stroke-dasharray="3 2"/>
      <circle cx="170" cy="40" r="12" fill="#5a6b52"/>
      <path d="M164 40 l4 4 l8-8" stroke="white" stroke-width="2" fill="none" stroke-linecap="round"/>
    </svg>`,
  },
  underside: {
    title: "Underside — Good Example",
    tips: [
      "Show the full underside if possible, or at least the center",
      "Saw marks clearly visible — look for arc or straight patterns",
      "Include visible fasteners — nails or screws in frame members",
      "Capture any structural joints or rail connections",
      "Good lighting — use a flashlight if needed, avoid glare",
    ],
    svg: `<svg viewBox="0 0 200 220" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%">
      <rect width="200" height="220" fill="#2a2218"/>
      <rect x="8" y="8" width="184" height="204" rx="2" fill="none" stroke="#5a4a30" stroke-width="1" stroke-dasharray="4 3"/>
      <!-- underside surface -->
      <rect x="20" y="30" width="160" height="140" rx="2" fill="#3a3020" stroke="#8b6914" stroke-width="1.5"/>
      <!-- center rail -->
      <rect x="90" y="30" width="18" height="140" fill="#4a3c28" stroke="#8b6914" stroke-width="1"/>
      <!-- cross rail -->
      <rect x="20" y="90" width="160" height="16" fill="#4a3c28" stroke="#8b6914" stroke-width="1"/>
      <!-- saw marks — arc pattern (circular saw) -->
      <path d="M30 40 Q60 55 90 40" stroke="#8b6914" stroke-width="0.8" fill="none" opacity="0.7"/>
      <path d="M30 50 Q60 65 90 50" stroke="#8b6914" stroke-width="0.8" fill="none" opacity="0.7"/>
      <path d="M30 60 Q60 75 90 60" stroke="#8b6914" stroke-width="0.8" fill="none" opacity="0.7"/>
      <path d="M110 40 Q140 55 170 40" stroke="#8b6914" stroke-width="0.8" fill="none" opacity="0.7"/>
      <path d="M110 50 Q140 65 170 50" stroke="#8b6914" stroke-width="0.8" fill="none" opacity="0.7"/>
      <!-- nails -->
      <circle cx="40" cy="95" r="3" fill="#c8b888"/>
      <circle cx="80" cy="95" r="3" fill="#c8b888"/>
      <circle cx="120" cy="95" r="3" fill="#c8b888"/>
      <circle cx="160" cy="95" r="3" fill="#c8b888"/>
      <!-- flashlight beam suggestion -->
      <ellipse cx="30" cy="150" rx="20" ry="12" fill="#f5efe4" opacity="0.12"/>
      <!-- label -->
      <text x="100" y="195" text-anchor="middle" font-size="8" fill="#8b6914" font-family="sans-serif">saw marks · fasteners · joints</text>
      <circle cx="170" cy="24" r="12" fill="#5a6b52"/>
      <path d="M164 24 l4 4 l8-8" stroke="white" stroke-width="2" fill="none" stroke-linecap="round"/>
    </svg>`,
  },
  construction: {
    title: "Construction Details — What to Photograph",
    // Multi-scenario: array of { label, checks, svg }
    // ExampleModal renders a tab for each scenario.
    scenarios: [
      {
        label: "Drawer Joint",
        checks: [
          "Joint fills most of the frame",
          "Pins and tails both visible",
          "Corner of the drawer box in view",
          "Sharp focus on the joint line",
        ],
        svg: `<svg viewBox="0 0 260 200" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%">
          <rect width="260" height="200" fill="#1e1610"/>
          <rect x="0" y="0" width="130" height="200" fill="#3d2e1a"/>
          <line x1="0" y1="30" x2="130" y2="32" stroke="#4a3820" stroke-width="1.2" opacity="0.6"/>
          <line x1="0" y1="60" x2="130" y2="58" stroke="#4a3820" stroke-width="1.0" opacity="0.5"/>
          <line x1="0" y1="95" x2="130" y2="97" stroke="#4a3820" stroke-width="1.2" opacity="0.6"/>
          <line x1="0" y1="130" x2="130" y2="128" stroke="#4a3820" stroke-width="0.8" opacity="0.4"/>
          <line x1="0" y1="160" x2="130" y2="162" stroke="#4a3820" stroke-width="1.0" opacity="0.5"/>
          <rect x="130" y="0" width="130" height="200" fill="#4a3820"/>
          <line x1="130" y1="25" x2="260" y2="27" stroke="#5a4830" stroke-width="1.0" opacity="0.5"/>
          <line x1="130" y1="55" x2="260" y2="53" stroke="#5a4830" stroke-width="0.8" opacity="0.4"/>
          <line x1="130" y1="85" x2="260" y2="87" stroke="#5a4830" stroke-width="1.2" opacity="0.5"/>
          <line x1="130" y1="120" x2="260" y2="118" stroke="#5a4830" stroke-width="0.8" opacity="0.4"/>
          <line x1="130" y1="155" x2="260" y2="157" stroke="#5a4830" stroke-width="1.0" opacity="0.5"/>
          <polygon points="118,0 142,0 148,40 112,40" fill="#2a1e10" stroke="#6a5030" stroke-width="0.8"/>
          <polygon points="118,54 140,54 145,94 115,94" fill="#2a1e10" stroke="#6a5030" stroke-width="0.8"/>
          <polygon points="120,108 141,108 146,148 116,148" fill="#2a1e10" stroke="#6a5030" stroke-width="0.8"/>
          <polygon points="119,162 140,162 144,200 117,200" fill="#2a1e10" stroke="#6a5030" stroke-width="0.8"/>
          <polygon points="118,0 130,0 130,20 115,20" fill="#2a1e10" stroke="#6a5030" stroke-width="0.8"/>
          <polygon points="148,40 156,40 152,54 145,54" fill="#150f08" opacity="0.55"/>
          <polygon points="145,94 153,94 149,108 142,108" fill="#150f08" opacity="0.55"/>
          <polygon points="146,148 154,148 150,162 143,162" fill="#150f08" opacity="0.55"/>
          <rect x="0" y="0" width="10" height="200" fill="url(#rl1)" opacity="0.4"/>
          <defs><linearGradient id="rl1" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stop-color="#f5d090" stop-opacity="0.7"/><stop offset="100%" stop-color="#f5d090" stop-opacity="0"/></linearGradient></defs>
          <rect x="4" y="6" width="114" height="16" rx="2" fill="#1a1410" opacity="0.7"/>
          <text x="10" y="17" font-size="9" fill="#7ab870" font-family="sans-serif" font-weight="600">✔ Joint fills the frame</text>
          <rect x="4" y="28" width="122" height="16" rx="2" fill="#1a1410" opacity="0.7"/>
          <text x="10" y="39" font-size="9" fill="#7ab870" font-family="sans-serif" font-weight="600">✔ Pins and tails visible</text>
          <rect x="4" y="50" width="128" height="16" rx="2" fill="#1a1410" opacity="0.7"/>
          <text x="10" y="61" font-size="9" fill="#7ab870" font-family="sans-serif" font-weight="600">✔ Corner of drawer box</text>
        </svg>`,
      },
      {
        label: "Internal Rail",
        checks: [
          "Rail or brace fills the frame",
          "How it connects to the case visible",
          "Secondary wood identifiable",
          "Fasteners at joints included",
        ],
        svg: `<svg viewBox="0 0 260 200" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%">
          <rect width="260" height="200" fill="#1a1c12"/>
          <rect x="0" y="120" width="260" height="80" fill="#2e2e1a"/>
          <line x1="0" y1="130" x2="260" y2="132" stroke="#3a3820" stroke-width="1" opacity="0.6"/>
          <line x1="0" y1="148" x2="260" y2="146" stroke="#3a3820" stroke-width="0.8" opacity="0.5"/>
          <line x1="0" y1="164" x2="260" y2="166" stroke="#3a3820" stroke-width="1" opacity="0.6"/>
          <rect x="0" y="0" width="20" height="200" fill="#302818"/>
          <rect x="240" y="0" width="20" height="200" fill="#302818"/>
          <rect x="0" y="55" width="260" height="28" fill="#a89060" rx="1"/>
          <line x1="0" y1="62" x2="260" y2="63" stroke="#b8a070" stroke-width="0.8" opacity="0.5"/>
          <line x1="0" y1="70" x2="260" y2="69" stroke="#b8a070" stroke-width="0.6" opacity="0.4"/>
          <line x1="0" y1="76" x2="260" y2="77" stroke="#b8a070" stroke-width="0.6" opacity="0.3"/>
          <rect x="18" y="60" width="14" height="18" fill="#1a1610" rx="1"/>
          <rect x="228" y="60" width="14" height="18" fill="#1a1610" rx="1"/>
          <polygon points="20,120 52,120 20,88" fill="#8a7048" stroke="#6a5030" stroke-width="0.8"/>
          <polygon points="240,120 208,120 240,88" fill="#8a7048" stroke="#6a5030" stroke-width="0.8"/>
          <circle cx="22" cy="69" r="4" fill="#706050" stroke="#4a3820" stroke-width="0.8"/>
          <circle cx="238" cy="69" r="4" fill="#706050" stroke="#4a3820" stroke-width="0.8"/>
          <rect x="0" y="0" width="260" height="55" fill="url(#tg1)" opacity="0.25"/>
          <defs><linearGradient id="tg1" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#e8d8a0" stop-opacity="0.5"/><stop offset="100%" stop-color="#e8d8a0" stop-opacity="0"/></linearGradient></defs>
          <rect x="4" y="6" width="128" height="16" rx="2" fill="#0e100a" opacity="0.75"/>
          <text x="10" y="17" font-size="9" fill="#7ab870" font-family="sans-serif" font-weight="600">✔ Rail fills the frame</text>
          <rect x="4" y="28" width="140" height="16" rx="2" fill="#0e100a" opacity="0.75"/>
          <text x="10" y="39" font-size="9" fill="#7ab870" font-family="sans-serif" font-weight="600">✔ Connection to case visible</text>
          <rect x="4" y="50" width="146" height="16" rx="2" fill="#0e100a" opacity="0.75"/>
          <text x="10" y="61" font-size="9" fill="#7ab870" font-family="sans-serif" font-weight="600">✔ Secondary wood identifiable</text>
        </svg>`,
      },
      {
        label: "Saw Marks",
        checks: [
          "Marks visible across the surface",
          "Raking light reveals the texture",
          "Arc or line pattern readable",
          "No flash glare hiding the marks",
        ],
        svg: `<svg viewBox="0 0 260 200" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%">
          <rect width="260" height="200" fill="#2e2010"/>
          <line x1="0" y1="20" x2="260" y2="22" stroke="#382a14" stroke-width="1.5" opacity="0.7"/>
          <line x1="0" y1="45" x2="260" y2="43" stroke="#382a14" stroke-width="1.2" opacity="0.6"/>
          <line x1="0" y1="72" x2="260" y2="74" stroke="#382a14" stroke-width="1.5" opacity="0.7"/>
          <line x1="0" y1="100" x2="260" y2="98" stroke="#382a14" stroke-width="1.0" opacity="0.5"/>
          <line x1="0" y1="128" x2="260" y2="130" stroke="#382a14" stroke-width="1.5" opacity="0.7"/>
          <line x1="0" y1="158" x2="260" y2="156" stroke="#382a14" stroke-width="1.2" opacity="0.6"/>
          <line x1="0" y1="182" x2="260" y2="184" stroke="#382a14" stroke-width="1.0" opacity="0.5"/>
          <path d="M-10,8 Q80,-12 170,8"  stroke="#c8a060" stroke-width="1.4" fill="none" opacity="0.85"/>
          <path d="M-10,22 Q80,2 170,22"  stroke="#c8a060" stroke-width="1.2" fill="none" opacity="0.8"/>
          <path d="M-10,36 Q80,16 170,36"  stroke="#c8a060" stroke-width="1.4" fill="none" opacity="0.85"/>
          <path d="M-10,50 Q80,30 170,50"  stroke="#c8a060" stroke-width="1.0" fill="none" opacity="0.7"/>
          <path d="M-10,64 Q80,44 170,64"  stroke="#c8a060" stroke-width="1.2" fill="none" opacity="0.8"/>
          <path d="M90,0 Q180,18 270,0"   stroke="#c8a060" stroke-width="1.4" fill="none" opacity="0.85"/>
          <path d="M90,14 Q180,32 270,14"  stroke="#c8a060" stroke-width="1.2" fill="none" opacity="0.8"/>
          <path d="M90,28 Q180,46 270,28"  stroke="#c8a060" stroke-width="1.4" fill="none" opacity="0.85"/>
          <path d="M90,42 Q180,60 270,42"  stroke="#c8a060" stroke-width="1.0" fill="none" opacity="0.7"/>
          <path d="M90,56 Q180,74 270,56"  stroke="#c8a060" stroke-width="1.2" fill="none" opacity="0.8"/>
          <path d="M-10,78 Q80,58 170,78"  stroke="#c8a060" stroke-width="1.3" fill="none" opacity="0.8"/>
          <path d="M-10,92 Q80,72 170,92"  stroke="#c8a060" stroke-width="1.1" fill="none" opacity="0.75"/>
          <path d="M-10,106 Q80,86 170,106" stroke="#c8a060" stroke-width="1.3" fill="none" opacity="0.8"/>
          <path d="M90,70 Q180,88 270,70"  stroke="#c8a060" stroke-width="1.3" fill="none" opacity="0.8"/>
          <path d="M90,84 Q180,102 270,84"  stroke="#c8a060" stroke-width="1.1" fill="none" opacity="0.75"/>
          <path d="M90,98 Q180,116 270,98"  stroke="#c8a060" stroke-width="1.3" fill="none" opacity="0.8"/>
          <path d="M-10,120 Q80,100 170,120" stroke="#c8a060" stroke-width="1.2" fill="none" opacity="0.8"/>
          <path d="M-10,134 Q80,114 170,134" stroke="#c8a060" stroke-width="1.0" fill="none" opacity="0.7"/>
          <path d="M-10,148 Q80,128 170,148" stroke="#c8a060" stroke-width="1.2" fill="none" opacity="0.8"/>
          <path d="M90,112 Q180,130 270,112" stroke="#c8a060" stroke-width="1.2" fill="none" opacity="0.8"/>
          <path d="M90,126 Q180,144 270,126" stroke="#c8a060" stroke-width="1.0" fill="none" opacity="0.7"/>
          <path d="M90,140 Q180,158 270,140" stroke="#c8a060" stroke-width="1.2" fill="none" opacity="0.8"/>
          <path d="M-10,162 Q80,142 170,162" stroke="#c8a060" stroke-width="1.1" fill="none" opacity="0.75"/>
          <path d="M-10,176 Q80,156 170,176" stroke="#c8a060" stroke-width="1.1" fill="none" opacity="0.75"/>
          <path d="M90,154 Q180,172 270,154" stroke="#c8a060" stroke-width="1.1" fill="none" opacity="0.75"/>
          <path d="M90,168 Q180,186 270,168" stroke="#c8a060" stroke-width="1.1" fill="none" opacity="0.75"/>
          <rect x="0" y="0" width="30" height="200" fill="url(#sr1)" opacity="0.35"/>
          <defs><linearGradient id="sr1" x1="0" y1="0" x2="1" y2="0"><stop offset="0%" stop-color="#f0d890" stop-opacity="0.7"/><stop offset="100%" stop-color="#f0d890" stop-opacity="0"/></linearGradient></defs>
          <rect x="4" y="142" width="154" height="16" rx="2" fill="#0e0a06" opacity="0.78"/>
          <text x="10" y="153" font-size="9" fill="#7ab870" font-family="sans-serif" font-weight="600">✔ Marks across full surface</text>
          <rect x="4" y="162" width="158" height="16" rx="2" fill="#0e0a06" opacity="0.78"/>
          <text x="10" y="173" font-size="9" fill="#7ab870" font-family="sans-serif" font-weight="600">✔ Arc pattern clearly readable</text>
          <rect x="4" y="182" width="148" height="16" rx="2" fill="#0e0a06" opacity="0.78"/>
          <text x="10" y="193" font-size="9" fill="#7ab870" font-family="sans-serif" font-weight="600">✔ No glare obscuring marks</text>
        </svg>`,
      },
    ],
  },
};

const CORE_SLOTS = [
  {
    key:          "overall_front",
    label:        "Overall Front",
    icon:         "⬜",
    desc:         "Shows full form and proportions",
    evidence_hint: null,
    has_example:  true,
  },
  {
    key:          "overall_side",
    label:        "Overall Side / Profile",
    icon:         "◧",
    desc:         "Shows depth, silhouette, and leg structure",
    evidence_hint: null,
    has_example:  true,
  },
  {
    key:          "underside",
    label:        "Underside",
    icon:         "⬇",
    desc:         "Reveals saw marks, fasteners, and hidden construction clues",
    evidence_hint: "Strongest dating surface — shows saw marks and nail types",
    has_example:  true,
  },
  {
    key:          "back",
    label:        "Back Panel",
    icon:         "⬛",
    desc:         "Reveals milling style, backboard construction, and materials",
    evidence_hint: "Useful for dating — shows secondary wood and milling technique",
    has_example:  false,
  },
  {
    key:          "label_makers_mark",
    label:        "Label or Maker's Mark",
    icon:         "🏷",
    desc:         "Paper labels, stamps, stencils, serial numbers, or branded hardware",
    optional:     true,
    evidence_hint: null,
    has_example:  false,
  },
];

// Multi-upload evidence groups
const EVIDENCE_GROUPS = [
  {
    key:        "hardware",
    image_type: "hardware_closeup",
    label:      "Hardware Evidence",
    icon:       "⬡",
    helper:     "Upload close-ups of any hardware that may help identify or date the piece — hinges, pulls, latches, locks, escutcheons, casters, catches, or brackets.",
    btnLabel:   "Add another hardware photo",
    has_example: false,
  },
  {
    key:        "construction",
    image_type: "joinery_closeup",
    label:      "Construction Details",
    icon:       "⊞",
    helper:     "Close-ups of joints, rails, dovetails, braces, or tool marks. Pull out a drawer and photograph the corner — or photograph any visible framing, braces, or saw marks on exposed surfaces.",
    btnLabel:   "Add another construction photo",
    has_example: true,
  },
];

const INTAKE_QS = [
  { key:"approximate_height", label:"Height (in)",                         type:"text",     placeholder:"e.g. 48",                               group:"dims" },
  { key:"approximate_width",  label:"Width (in)",                          type:"text",     placeholder:"e.g. 36",                               group:"dims" },
  { key:"primary_wood_guess", label:"Wood species",                        type:"text",     placeholder:"walnut, oak, unknown…",                 group:"main" },
  { key:"where_acquired",     label:"Where acquired",                      type:"text",     placeholder:"estate sale, dealer, attic…",           group:"main" },
  { key:"known_provenance",   label:"Known history or provenance",         type:"textarea", placeholder:"Family history, labels, inscriptions…", group:"main" },
  { key:"known_alterations",  label:"Anything altered, missing, or replaced?", type:"textarea", placeholder:"Examples: replaced hardware, missing drawers, added top, missing mirror, converted from another use", group:"main" },
  { key:"user_category_guess",label:"What do you think it is?",               type:"text",     placeholder:"desk, cabinet, table…",                 group:"main" },
  { key:"condition_notes",    label:"Condition or restoration notes",          type:"textarea", placeholder:"Examples: scratches, veneer lifting, refinished surface, loose joints, repairs", group:"main" },
];

// Functional clue toggles — feed conversion detection in Phase 3 / Conflict Engine
const FUNCTIONAL_CLUES = [
  { key:"has_drawers",           label:"Does it have drawers?" },
  { key:"has_doors",             label:"Does it have doors?" },
  { key:"folds_or_expands",      label:"Does it fold or expand?" },
  { key:"has_mechanical_parts",  label:"Does it have pedals, cranks, or mechanical parts?" },
  { key:"suggests_prior_function",label:"Does anything suggest it used to serve another function?" },
];

// ── Expert-voice guidance messages ───────────────────────────
// Keyed to missing_evidence flags. Benefit-based, "if available"
// phrasing. Never warnings — always appraiser-style suggestions.
const GUIDANCE_MESSAGES = {
  underside_photo: {
    icon: "⬇",
    text: "If available, an underside photo often reveals saw marks and fasteners that help date a piece.",
  },
  back_photo: {
    icon: "⬛",
    text: "A back panel photo can reveal milling style and backboard construction used in different periods.",
  },
  joinery_photo: {
    icon: "⊞",
    text: "Close-ups of drawer joinery or internal framing can help confirm construction methods.",
  },
  hardware_photo: {
    icon: "⬡",
    text: "Hardware close-ups can help determine whether hinges, pulls, or casters are original to the piece.",
  },
  label_photo: {
    icon: "🏷",
    text: "Maker labels or stamped marks can sometimes identify the manufacturer.",
  },
};

// Compute missing evidence flags from current image state (for intake UI).
// Mirrors the logic in API.analyzeCase so guidance is live before analysis runs.
function computeMissingEvidence(images, groupImages) {
  const imageKeys = new Set(Object.keys(images));
  const groupTypes = new Set(Object.values(groupImages).flat().map(i => i.image_type));
  return {
    underside_photo: !imageKeys.has("underside"),
    back_photo:      !imageKeys.has("back"),
    joinery_photo:   !imageKeys.has("joinery_closeup") && !groupTypes.has("joinery_closeup"),
    hardware_photo:  !imageKeys.has("hardware_closeup") && !groupTypes.has("hardware_closeup"),
    label_photo:     !imageKeys.has("label_makers_mark"),
  };
}

// Render the guidance block given a missing_evidence map.
// Used in both the intake screen and the report page.
function GuidanceMessages({ missing, totalPhotos, style }) {
  if (!missing || totalPhotos < 2) return null;
  const active = Object.entries(missing)
    .filter(([, v]) => v)
    .map(([k]) => GUIDANCE_MESSAGES[k])
    .filter(Boolean);
  if (active.length === 0) return null;
  return (
    <div style={{ ...guidanceStyles.block, ...style }}>
      <div style={guidanceStyles.title}>To strengthen results, if available:</div>
      {active.map((g, i) => (
        <div key={i} style={guidanceStyles.row}>
          <span style={guidanceStyles.icon}>{g.icon}</span>
          <span style={guidanceStyles.text}>{g.text}</span>
        </div>
      ))}
    </div>
  );
}

const guidanceStyles = {
